#version 140

#define SHADER_DH_TERRAIN
#define NETHER
#define FSH

#include "/common/settings.glsl"
#include "/common/uniforms.glsl"
#include "/common/common.glsl"

#include "/program/dh_terrain.glsl"
