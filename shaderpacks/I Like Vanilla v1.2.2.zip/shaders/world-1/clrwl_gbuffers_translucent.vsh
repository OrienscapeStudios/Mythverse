#version 140

#define SHADER_CLRWL_GBUFFERS_TRANSLUCENT
#define NETHER
#define VSH

#include "/common/settings.glsl"
#include "/common/uniforms.glsl"
#include "/common/common.glsl"

#include "/program/clrwl_gbuffers_translucent.glsl"
