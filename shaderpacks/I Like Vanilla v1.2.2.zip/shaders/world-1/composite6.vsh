#version 140

#define SHADER_COMPOSITE6
#define NETHER
#define VSH

#include "/common/settings.glsl"
#include "/common/uniforms.glsl"
#include "/common/common.glsl"

#include "/program/composite6.glsl"
