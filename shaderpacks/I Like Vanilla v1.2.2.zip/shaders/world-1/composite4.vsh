#version 140

#define SHADER_COMPOSITE4
#define NETHER
#define VSH

#include "/common/settings.glsl"
#include "/common/uniforms.glsl"
#include "/common/common.glsl"

#include "/program/composite4.glsl"
