#version 140

#define SHADER_GBUFFERS_TEXTURED
#define NETHER
#define VSH

#include "/common/settings.glsl"
#include "/common/uniforms.glsl"
#include "/common/common.glsl"

#include "/program/gbuffers_textured.glsl"
