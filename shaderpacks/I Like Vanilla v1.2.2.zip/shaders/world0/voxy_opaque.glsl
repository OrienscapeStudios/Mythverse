#define SHADER_VOXY_OPAQUE
#define SHADER_VOXY
#define OVERWORLD
#define FSH

#include "/common/settings.glsl"
#include "/common/common.glsl"

#include "/program/voxy_opaque.glsl"
