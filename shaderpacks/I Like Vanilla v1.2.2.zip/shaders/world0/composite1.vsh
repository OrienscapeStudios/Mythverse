#version 140

#define SHADER_COMPOSITE1
#define OVERWORLD
#define VSH

#include "/common/settings.glsl"
#include "/common/uniforms.glsl"
#include "/common/common.glsl"

#include "/program/composite1.glsl"
