#version 140

#define SHADER_COMPOSITE4
#define OVERWORLD
#define FSH

#include "/common/settings.glsl"
#include "/common/uniforms.glsl"
#include "/common/common.glsl"

#include "/program/composite4.glsl"
