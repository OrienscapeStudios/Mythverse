#version 140

#define SHADER_GBUFFERS_BASIC
#define OVERWORLD
#define VSH

#include "/common/settings.glsl"
#include "/common/uniforms.glsl"
#include "/common/common.glsl"

#include "/program/gbuffers_basic.glsl"
