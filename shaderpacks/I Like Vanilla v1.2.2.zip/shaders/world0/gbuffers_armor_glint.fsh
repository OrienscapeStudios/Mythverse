#version 140

#define SHADER_GBUFFERS_ARMOR_GLINT
#define OVERWORLD
#define FSH

#include "/common/settings.glsl"
#include "/common/uniforms.glsl"
#include "/common/common.glsl"

#include "/program/gbuffers_armor_glint.glsl"
