#version 140

#define SHADER_GBUFFERS_HAND
#define OVERWORLD
#define VSH

#include "/common/settings.glsl"
#include "/common/uniforms.glsl"
#include "/common/common.glsl"

#include "/program/gbuffers_hand.glsl"
