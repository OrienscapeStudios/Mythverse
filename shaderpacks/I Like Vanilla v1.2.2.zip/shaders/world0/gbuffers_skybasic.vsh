#version 140

#define SHADER_GBUFFERS_SKYBASIC
#define OVERWORLD
#define VSH

#include "/common/settings.glsl"
#include "/common/uniforms.glsl"
#include "/common/common.glsl"

#include "/program/gbuffers_skybasic.glsl"
