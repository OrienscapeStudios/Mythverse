#version 140

#define SHADER_DH_WATER
#define END
#define FSH

#include "/common/settings.glsl"
#include "/common/uniforms.glsl"
#include "/common/common.glsl"

#include "/program/dh_water.glsl"
