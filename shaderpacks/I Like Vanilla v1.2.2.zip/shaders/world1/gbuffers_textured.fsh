#version 140

#define SHADER_GBUFFERS_TEXTURED
#define END
#define FSH

#include "/common/settings.glsl"
#include "/common/uniforms.glsl"
#include "/common/common.glsl"

#include "/program/gbuffers_textured.glsl"
