#version 140

#define SHADER_CLRWL_GBUFFERS
#define END
#define FSH

#include "/common/settings.glsl"
#include "/common/uniforms.glsl"
#include "/common/common.glsl"

#include "/program/clrwl_gbuffers.glsl"
