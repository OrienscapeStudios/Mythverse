#version 140

#define SHADER_COMPOSITE5
#define END
#define VSH

#include "/common/settings.glsl"
#include "/common/uniforms.glsl"
#include "/common/common.glsl"

#include "/program/composite5.glsl"
