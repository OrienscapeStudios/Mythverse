#version 140

#define SHADER_GBUFFERS_SKYTEXTURED
#define END
#define FSH

#include "/common/settings.glsl"
#include "/common/uniforms.glsl"
#include "/common/common.glsl"

#include "/program/gbuffers_skytextured.glsl"
